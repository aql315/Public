# -*- coding: utf-8 -*-
"""
Created on Mon May 13 13:02:26 2019

@author:  Aqeel Bohoran
"""
import os,sys
import time

def Database_subprocess(makeDB):
#    os.chdir(chdir)
#    os.popen(makeDB).readline()
    tablepath = os.path.dirname(os.path.realpath(__file__))
    
    for i in range(3):
        time.sleep (2)
        makeDB=makeDB.replace("TrainSet1","TrainSet"+str(i+1))
        makeDB=makeDB.replace("TrainSet2","TrainSet"+str(i+1))
        makeDB=makeDB.replace("pic_lmdb","pic_lmdb"+str(i+1))





        S=os.system(makeDB)
        
        with open(os.path.join(tablepath, "DBFile.txt"), 'w') as p:
            p.write(str(S))
            p.close
    
def tic():
    global _start_time 
    _start_time = time.time()
    
def tac():
    tablepath = os.path.dirname(os.path.realpath(__file__))
    t_sec = round(time.time() - _start_time)
    (t_min, t_sec) = divmod(t_sec,60)
    (t_hour,t_min) = divmod(t_min,60) 
    with open(os.path.join(tablepath, "DBTime.txt"), 'w') as p:
           p.write(str('{}\n{}\n{}'.format(t_hour,t_min,t_sec)))
           p.close
    
if __name__ == "__main__":
#    makeDB="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/convert_imageset e:/AI/picture/code_9/ e:/AI/AI_param/code_9/Optimization/TrainSet1.txt e:/AI/AI_param/code_9/Optimization/pic_lmdb -backend lmdb --shuffle --resize_height 500 --resize_width 500 2>>lmdb.txt"
#    makeDB="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/convert_imageset e:/AI/picture/code_9/ E:/AI/AI_param/code_9/Optimization/TrainSet1.txt e:/AI/AI_param/code_9/Optimization/pic_lmdb -backend lmdb --shuffle --resize_height 500 --resize_width 500"
#    chdir="C:/cffnew"

    _start_time = time.time()
    makeDB = input()

    tic()
    Database_subprocess(makeDB)
    tac()

    


