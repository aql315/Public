# -*- coding: utf-8 -*-
"""
Created on Thu May  9 18:07:47 2019

@author: Aqeel Bohoran
"""
import os,sys
from bayes_opt import BayesianOptimization
#from bayes_opt.util import Colours
from caffe.proto import caffe_pb2
import xlsxwriter
import time
import random
from tkinter import messagebox
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
import csv
from sklearn import metrics
import numpy as np
import time
import math
trycount = 0


def tic():
    global _start_time 
    _start_time = time.time()
    
def tac():
    t_sec = round(time.time() - _start_time)
    (t_min, t_sec) = divmod(t_sec,60)
    (t_hour,t_min) = divmod(t_min,60) 
    
    
    with open(os.path.join(tablepath, "Time.txt"), 'w') as p:
           p.write(str('{}\n{}\n{}'.format(t_hour,t_min,t_sec)))
           p.close

def optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,LR_Low, LR_UP,WD_Low,WD_UP,Progresspath,tablepath,OptIter,TrainIter,OptInitial,opttypemodel,imagedir,momentumLow,momentumUP,lr_policy_1,GammaLow,GammaUP,StepLow,StepUP,momentum2Low,momentum2UP,modelcount,Batchsize):

    def brew_caffe(LR,WD,momentum,gamma,step,momentum2):
        global trycount

        os.chdir(chdir)  
        
        ############### DO Testing###################################

        CaffeModel=chdir+"/snapshot/"
        
        Deploy=chdir+"/inspection_model/AISetting.prototxt"
#        caffe_classifier ="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/classification" #Does not thange for this computer
        
        caffe_classifier ="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/DLLmakeConf.exe" 

        classLabel=imagedir+"/class.txt"

  

        Validation=[]
        
        labels=[]
        
        f = open(classLabel)
        for i in f:
             labels.append(i)
        f.close()
        

        for j in range(3):
            
            try: 
                Newtrain_net_path =train_net_path.replace("train_model","train_model"+str(j+1))
            except:
                pass

            s = caffe_pb2.SolverParameter()

            #do-make-solver
            base_lr=LR
            s.train_net = Newtrain_net_path
            #s.test_net.append(test_net_path)
            s.lr_policy= lr_policy_1
            s.base_lr= base_lr
            if lr_policy_1== "multistep":
                s.stepvalue.append((int(step)))
                #s.stepvalue.append(int(TrainIter*(3/4)))
            else:
                pass

            s.momentum= momentum
            s.momentum2= momentum2
            s.weight_decay= WD
            s.gamma= gamma
            s.power= 0.75
            s.display= 1000
            s.max_iter=TrainIter
            s.snapshot= TrainIter
            s.snapshot_prefix= snapshot_path
            s.type= opttypemodel
            s.solver_mode= 1
        
            with open(solver_config_path, 'w') as f:
                f.write(str(s))
            try:
                os.remove("test.txt")
            except:
                pass
            

            S=os.system(Train)  
            if not S == 0 :
                print(S,"Train Failed!")
                messagebox.showinfo("Err", "Train Failed!")

            with open(os.path.join(tablepath, "TrainStat.txt"), 'w') as p:
                p.write(str(S))
                p.close

            MeanFile=chdir+"/mean"+str(j+1)+"/mean.binaryproto"
            Image_File=chdir+"/ValSet"+str(j+1)+".txt"

            time.sleep (1)
            #do-classify
            classify= str(caffe_classifier+" "+imagedir+" "+Image_File+" "+Deploy+" "+MeanFile+" "+CaffeModel+" "+chdir+"/confi"+" "+str(TrainIter)+"00"+" "+Batchsize+" "+str(0))

            os.popen(classify).read()

            SoftMax =[]
            Actual =[]
            Pred =[]

            f =open(imagedir+"/class.txt","r")
            
            ok_Class=0
            for i in f:
                Class_Num =i[-3:]
                if int(Class_Num) == 0:
                    ok_Class =ok_Class + 1          
            f.close()
            
            #makeTrainResult
            f =open(chdir+"/confi/cmInfo"+str(TrainIter)+".txt","r")
             
            if j==0:
                fa=open(chdir+"/confR/"+str(modelcount)+"_"+str(opttypemodel)+"_"+str(lr_policy_1)+"_"+str(trycount)+".txt","w")
            else:
                fa=open(chdir+"/confR/"+str(modelcount)+"_"+str(opttypemodel)+"_"+str(lr_policy_1)+"_"+str(trycount)+".txt","a")
            for line in f:
                s_new = ''.join(line.splitlines())
                print(s_new, file=fa)
                data = line[:-1].split("|")
                Actual.append(int(data[0]))
                Pred.append(int(data[1]))
                SoftMax.append(float(data[2]))
            y_score = []
            for i in range(len(Actual)):
                if math.isnan(SoftMax[i]):
                    y_score.append(0)

                else:
                    if Pred[i] >= ok_Class:
                        y_score.append(SoftMax[i])
                    else:
                        y_score.append(1-SoftMax[i])
            fa.close()
            
            y_true=[]  
            for i in Actual:
                if i >= ok_Class:
                    y_true.append(1)
                else:
                    y_true.append(0)
            

            fpr, tpr, thresholds = metrics.roc_curve(y_true, y_score, drop_intermediate=False)
            auc = np.trapz(tpr,fpr)
            Validation.append(round(auc,6))


        avarage=sum(Validation)/3
        with open(os.path.join(Progresspath, str(WD)+str(random.randint(1,1001))+'loss.txt'), 'w') as f:
           f.writelines(str(avarage))
        trycount+= 1
        return avarage
        
#################################################################################

    optimizer = BayesianOptimization(
        f=brew_caffe,
        pbounds={ "LR": (LR_Low, LR_UP),"WD": (WD_Low,WD_UP),"momentum": (momentumLow,momentumUP),"gamma": (GammaLow,GammaUP),"step": (StepLow,StepUP),"momentum2": (momentum2Low,momentum2UP)},
        random_state=1,
        verbose=2
    )
    optimizer.maximize(n_iter=int(OptIter),init_points=int(OptInitial),alpha=1e-3)  #OptInitial
    
    MinimumIndex=[]
    Target=[]
    param=[]
    Learn=[]
    WaightDC=[]
    Momentam=[]
    Momentam2=[]
    Gamma=[]
    Step=[]
    
    

    for i in optimizer.res:
        gx= i["target"]
        MinimumIndex.append(gx)
    Index = MinimumIndex.index(max(MinimumIndex))

    
           
    for i in optimizer.res:
        gx= i["target"]
        Target.append(gx)
        gx1= i["params"]
        param.append(gx1)
    

    
        
    for i in param:
        gx= i["LR"]
        Learn.append(round(gx,6))
        gx1= i["WD"]
        WaightDC.append(round(gx1,6))
        gx2= i["momentum"]
        Momentam.append(round(gx2,6))
        gx3=i["gamma"]
        Gamma.append(round(gx3,6))        
        gx4=i["step"]
        Step.append(round(gx4,6))        
        gx5=i["momentum2"]
        Momentam2.append(round(gx5,6)) 
#        
    differance =(OptIter+OptInitial)-len(optimizer.res)
    if len(optimizer.res) <(OptIter+OptInitial):
        for i in range(differance):
            gx= Target[len(optimizer.res)-1]
            Target.append(gx)
            gx1= Learn[len(optimizer.res)-1]
            Learn.append(gx1)
            gx2= WaightDC[len(optimizer.res)-1]
            WaightDC.append(gx2)
            

    
    
    table=[]

    if range(len(Target))== range(len(Momentam)):
        for i in range(len(Target)):
            table.extend([[Momentam[i],WaightDC[i],Learn[i],Target[i],i+1,Gamma[i],Step[i],Momentam2[i]]])    
    else:
        for i in range(len(Momentam)):
            table.extend([[Momentam[i],WaightDC[i],Learn[i],Target[i],i+1,Gamma[i],Step[i],Momentam2[i]]])

    rowHead=[["慣性項","重み更新量","学習率","AUC","試行 NO","重み更新係数","重み更新タイミング","慣性項2"]]
    workbook = xlsxwriter.Workbook(os.path.join(tablepath,str(opttypemodel)+"_"+str(lr_policy_1)+'.xlsx'))
    worksheet = workbook.add_worksheet()     
    worksheet.add_table('A1:H1', {'data': rowHead,'header_row': False})
    worksheet.add_table('A2:H100', {'data': table,'header_row': False})
    workbook.close()
    
    with open(os.path.join(tablepath, str(opttypemodel)+"_"+str(lr_policy_1)+"_"+"index.txt"), 'w') as p:
           p.write((str(Learn[Index]))+"\n"+(str(WaightDC[Index]))+"\n"+(str(Index))+"\n"+(str(Target[Index]))+"\n"+(str(Momentam[Index]))+"\n"+(str(Gamma[Index]))+"\n"+(str(Step[Index]))+"\n"+(str(Momentam2[Index])))
           p.close
    

    
if __name__ == "__main__":
     

     
     OptIter     = int(sys.argv[1])
     
     Train       = input()
     if Train is not None:
         solver_config_path= input()
     if solver_config_path and Train is not None:
         train_net_path= input()
     if solver_config_path and Train and train_net_path is not None:
         chdir= input()
     if solver_config_path and Train and train_net_path and chdir is not None:
        OptType= input()
     if solver_config_path and Train and train_net_path and chdir and OptType is not None:
        imagedir= input()

     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir is not None:
        momentumLow= input()
        momentumLow=float(momentumLow)
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow  is not None:
        momentumUP= input()
        momentumUP=float(momentumUP)
     
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP is not None:
        LR_Low= input()
        LR_Low=float(LR_Low)
     
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low is not None:
        LR_UP= input()
        LR_UP=float(LR_UP)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP is not None:
        WD_Low= input()
        WD_Low=float(WD_Low)
     
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low is not None:
        WD_UP= input()
        WD_UP=float(WD_UP)
        

        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter is not None:
        TrainIter= input()
        TrainIter=int(TrainIter)
    
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter is not None:
        OptInitial= input()
        OptInitial=int(OptInitial) 
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial is not None:
        snapshot_path= input()
        snapshot_path=str(snapshot_path) 
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path is not None:
        policy= input()
        policy=str(policy)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy is not None:
        GammaLow= input()
        GammaLow=float(GammaLow)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow is not None:
        GammaUP= input()
        GammaUP=float(GammaUP)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP is not None:
        StepLow= input()
        StepLow=float(StepLow)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP and StepLow is not None:
        StepUP= input()
        StepUP=float(StepUP)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP and StepLow and StepUP is not None:
        momentum2Low= input()
        momentum2Low=float(momentum2Low)
        
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP and StepLow and StepUP and momentum2Low is not None:
        momentum2UP= input()
        momentum2UP=float(momentum2UP)
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP and StepLow and StepUP and momentum2Low and momentum2UP is not None:
        modelcount= input()
        modelcount=float(modelcount)
     if solver_config_path and Train and train_net_path and chdir and OptType and imagedir and momentumLow and momentumUP and LR_Low and LR_UP and WD_Low and WD_UP and OptIter and TrainIter and OptInitial and snapshot_path and policy and GammaLow and GammaUP and StepLow and StepUP and momentum2Low and momentum2UP and modelcount is not None:
        Batchsize= input()
#
     
     Progresspath = os.path.dirname(os.path.realpath(__file__))+"\progress"
     tablepath = os.path.dirname(os.path.realpath(__file__))
           
     
     
     if OptType=="001":
         loop=["Adam"]
         
     elif OptType=="010":
         loop=["Nesterov"]
         
     elif OptType=="011":
         loop=["Adam","Nesterov"]
     
     elif OptType=="100":
         loop=["SGD"]
    
     elif OptType=="101":
         loop=["Adam","SGD"]
    
     elif OptType=="110":
         loop=["Nesterov","SGD"]
         
     elif OptType=="111":
         loop=["Adam","Nesterov","SGD"]
         
     if policy == "m":
        loop2 = ['multistep']
     elif policy == "f":
        loop2 = ['fixed']
     elif policy =="fm":
        loop2 = ['multistep','fixed']         
        
    
     _start_time = time.time()

     tic()
     for i in loop:
         print(i)
         opttypemodel=i
         for j in loop2:
             print(j)
             lr_policy_1=j
             try:
                 if opttypemodel=="Adam":
                     if lr_policy_1=='multistep':
                         trycount=0
                         optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,LR_Low, LR_UP,WD_Low,WD_UP,Progresspath,tablepath,OptIter,TrainIter,OptInitial,opttypemodel,imagedir,momentumLow,momentumUP,lr_policy_1,GammaLow,GammaUP,StepLow,StepUP,momentum2Low,momentum2UP,modelcount,Batchsize)
                     else:
                         trycount=0
                         optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,LR_Low, LR_UP,WD_Low,WD_UP,Progresspath,tablepath,OptIter,TrainIter,OptInitial,opttypemodel,imagedir,momentumLow,momentumUP,lr_policy_1,0.1,0.1,1,1,momentum2Low,momentum2UP,modelcount,Batchsize)
                 else:
                     if lr_policy_1=='multistep':
                         trycount=0
                         optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,LR_Low, LR_UP,WD_Low,WD_UP,Progresspath,tablepath,OptIter,TrainIter,OptInitial,opttypemodel,imagedir,momentumLow,momentumUP,lr_policy_1,GammaLow,GammaUP,StepLow,StepUP,0.9,0.9,modelcount,Batchsize)
                     else:
                         trycount=0
                         optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,LR_Low, LR_UP,WD_Low,WD_UP,Progresspath,tablepath,OptIter,TrainIter,OptInitial,opttypemodel,imagedir,momentumLow,momentumUP,lr_policy_1,0.1,0.1,1,1,0.9,0.9,modelcount,Batchsize)
             except Exception as e:
                 with open(os.path.join(Progresspath, 'FinalFilelossError.txt'), 'w') as fe:
                     fe.write('type:' + str(type(e))+"\n")
                     fe.write('args:' + str(e.args)+"\n")
                     fe.write('message:' + str(e.message)+"\n")
                     fe.write('e自身:' + str(e)+"\n")
                     fe.close
     tac()
     with open(os.path.join(Progresspath, 'FinalFileloss.txt'), 'w') :
         pass