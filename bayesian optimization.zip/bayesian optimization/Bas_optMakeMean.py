# -*- coding: utf-8 -*-
"""
Created on Mon May 13 13:05:14 2019

@author: Aqeel Bohoran
"""

import os,sys
import time
def MeanFile_subprocess(MakeMean,chdir):
    os.chdir(chdir)
#    os.popen(MakeMean).readline()
    tablepath = os.path.dirname(os.path.realpath(__file__))
    
    for i in range(3):
        time.sleep (2)
        MakeMean=MakeMean.replace("mean/","mean"+str(i+1)+"/")
        MakeMean=MakeMean.replace("mean1/","mean"+str(i+1)+"/")
        MakeMean=MakeMean.replace("mean2/","mean"+str(i+1)+"/")
        MakeMean=MakeMean.replace("pic_lmdb","pic_lmdb"+str(i+1))
        
        print(MakeMean)
        S=os.system(MakeMean)
        print(S)
        with open(os.path.join(tablepath, "MeanFile.txt"), 'w') as p:
            p.write(str(S))
            p.close
#        with open(os.path.join(tablepath, "MeanPass"+str(i+1)+".txt"), 'w') as p:
#            p.write(str(MakeMean))
#            p.close
           

def tic():
    global _start_time 
    _start_time = time.time()
    
def tac():
    tablepath = os.path.dirname(os.path.realpath(__file__))
    t_sec = round(time.time() - _start_time)
    (t_min, t_sec) = divmod(t_sec,60)
    (t_hour,t_min) = divmod(t_min,60) 
    print(tablepath)
    with open(os.path.join(tablepath, "MeanTime.txt"), 'w') as p:
           p.write(str('{}\n{}\n{}'.format(t_hour,t_min,t_sec)))
           p.close
    
    
    
if __name__ == "__main__":
    
#    MakeMean="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/compute_image_mean pic_lmdb mean/mean.binaryproto -backend lmdb"
#    chdir="e:/AI/AI_param/code_1/Optimization"
    chdir=os.path.join(sys.argv[1])
    MakeMean= input()
    _start_time = time.time()

    tic()
    MeanFile_subprocess(MakeMean,chdir)
    tac()
    
#    

#C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/compute_image_mean e:/AI/AI_param/code_9/pic_data/Optimization/pic_lmdb e:/AI/AI_param/code_9/pic_data/Optimization/mean/mean.binaryproto -backend lmdb"