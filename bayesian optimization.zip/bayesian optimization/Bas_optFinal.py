# -*- coding: utf-8 -*-
"""
Created on Thu May  9 18:07:47 2019

@author: Aqeel Bohoran
"""
import os,sys
from bayes_opt import BayesianOptimization
#from bayes_opt.util import Colours
from caffe.proto import caffe_pb2
import xlsxwriter
import time
import random
from tkinter import messagebox
MinimumIndex=[]
Target=[]
param=[]
Learn=[]
WaightDC=[]


def tic():
    global _start_time 
    _start_time = time.time()
    
def tac():
    t_sec = round(time.time() - _start_time)
    (t_min, t_sec) = divmod(t_sec,60)
    (t_hour,t_min) = divmod(t_min,60) 
    
    with open(os.path.join(tablepath, "Time.txt"), 'w') as p:
           p.write(str('{}:{}:{}'.format(t_hour,t_min,t_sec)))
           p.close

def optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,Para1Up, para1low,para2Up,para2low,Progresspath,tablepath,OptIter,TrainIter,OptInitial):
    
    
       
    def brew_caffe(LR,WD):
        
 
        

#        for f in snapshot_path:
#            os.remove(f)
        s = caffe_pb2.SolverParameter()
#        solver_config_path="C:/cffnew/solver/AISetting2.prototxt"
#        train_net_path="C:/cffnew/train_model/AISetting.prototxt"
#        snapshot_path ="C:/cffnew/snapshot/model"
        base_lr=LR
            # Set a seed for reproducible experiments:
                # this controls for randomization in training.
                #s.random_seed = 0xCAFFE

    # Specify locations of the train and (maybe) test networks.
        s.train_net = train_net_path
        #s.test_net.append(test_net_path)
        s.lr_policy= "fixed"
        s.base_lr= base_lr
        s.momentum= 0.9
        s.momentum2= 0.999
        s.weight_decay= WD
        s.gamma= 0.0001
        s.power= 0.75
        s.display= 1
        s.max_iter=TrainIter
        s.snapshot= TrainIter
        s.snapshot_prefix= snapshot_path
        s.type= "Adam"
        s.solver_mode= 1
        
        with open(solver_config_path, 'w') as f:
            f.write(str(s))
        
        os.chdir(chdir)
        try:
            os.remove("test.txt")
        except:
            pass
#        os.popen(Train).readline()
        os.system(Train)
#        subprocess.call([chdir, Train], shell=True)
        
        with open(chdir+"/test.txt","r") as f_in:
            for row in f_in.readlines()[-3:-2] :
                start = row.find("loss =")
#            print(row[start:].replace("loss =",""))
        loss=row[start:].replace("loss =","")
        
        with open(os.path.join(Progresspath, str(random.randint(1,1001))+'loss.txt'), 'w'):
           pass
        
        return float(loss)
#################################################################################
        
    optimizer = BayesianOptimization(
        f=brew_caffe,
        pbounds={"LR": (para1Up, para1low), "WD": (para2Up,para2low)},
        random_state=None,
        verbose=2
    )
    optimizer.maximize(n_iter=OptIter,init_points=OptInitial)

#    finding the minimum point for loss
    for i in optimizer.res:
        gx= i["target"]
        MinimumIndex.append(gx)
    Index = MinimumIndex.index(min(MinimumIndex))
#    print("Final result:",optimizer.res[Index] )
    
           
    for i in optimizer.res:
        gx= i["target"]
        Target.append(gx)
        gx1= i["params"]
        param.append(gx1)
    

    
        
    for i in param:
        gx= i["LR"]
        Learn.append(round(gx,6))
        gx1= i["WD"]
        WaightDC.append(round(gx1,6))
    
    differance =(OptIter+OptInitial)-len(optimizer.res)
    if len(optimizer.res) <(OptIter+OptInitial):
        for i in range(differance):
            gx= Target[len(optimizer.res)-1]
            Target.append(gx)
            gx1= Learn[len(optimizer.res)-1]
            Learn.append(gx1)
            gx2= WaightDC[len(optimizer.res)-1]
            WaightDC.append(gx2)
            with open(os.path.join(Progresspath, str(random.randint(1,1001))+'loss.txt'), 'w'):
                pass
    
    
    table=[]
    for i in range(len(Target)):
        table.extend([[i+1,Target[i],Learn[i],WaightDC[i]]])
    rowHead=[["試行回数","Loss値","学習率","重み更新量"]]
    workbook = xlsxwriter.Workbook(os.path.join(tablepath,'TrainLossdata.xlsx'))
    worksheet = workbook.add_worksheet()     
    worksheet.add_table('A1:D1', {'data': rowHead,'header_row': False})
    worksheet.add_table('A2:D100', {'data': table,'header_row': False})
    workbook.close()
    
    with open(os.path.join(tablepath, "index.txt"), 'w') as p:
           p.write((str(Learn[Index]))+"\n"+(str(WaightDC[Index]))+"\n"+(str(Index)))
           p.close
    
if __name__ == "__main__":
    
#    Train="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/caffe train --solver=C:/cffnew/solver/AISetting2.prototxt 2>test.txt "
     
#     Train="C:/caffe/caffe_vb2015_CUDA8.0_Python2.7/bin/caffe train --solver=E:/AI/AI_param/code_9/pic_data/Optimization/solver/AISetting.prototxt 2>test.txt "
#     solver_config_path="e:/AI/AI_param/code_9/pic_data/Optimization/solver/AISetting.prototxt"
#     train_net_path=r"E:\AI\AI_param\code_9\pic_data\Optimization\train_model\AISetting.prototxt"
#     snapshot_path ="E:/AI/AI_param/code_9/pic_data/Optimization/snapshot/"
#     chdir="e:/AI/AI_param/code_9/pic_data/Optimization"
#     
#     para1Up= 0.0001
#     para1low=0.00001
#    
#     para2Up=0.05
#     para2low=0.0005
#    
#     OptIter  = 7
#     TrainIter= 1
#     OptInitial=2

     try:
        para1Up     = float(sys.argv[1])
        para1low    = float(sys.argv[2])
    
        para2Up     = float(sys.argv[3])
        para2low    = float(sys.argv[4])
    
        OptIter     = int(sys.argv[5])
        TrainIter   = int(sys.argv[6])
        OptInitial  = int(sys.argv[7])
    
        snapshot_path=str((sys.argv[8]))
        
     except:
        messagebox.showinfo("Err", "Input Training Values Are Wrong!")
    
     Train       = input()
     if Train is not None:
         solver_config_path= input()

     if solver_config_path and Train is not None:
         train_net_path= input()
     if solver_config_path and Train and train_net_path is not None:
         chdir= input()
#     
     Progresspath = os.path.dirname(os.path.realpath(__file__))+"\progress"
     tablepath = os.path.dirname(os.path.realpath(__file__))
    


     _start_time = time.time()

     tic()
     optimize_Caffe(chdir,Train,solver_config_path,train_net_path,snapshot_path,para1Up, para1low,para2Up,para2low,Progresspath,tablepath,OptIter,TrainIter,OptInitial)
     tac()